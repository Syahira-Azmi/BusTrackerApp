package com.example.bustrackerapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class RegisterActivity extends AppCompatActivity {

    private EditText etUserID, etFullName, etEmail, etPhoneNumber, etPassword;
    private CheckBox cbAgreeTerms;
    private Button btnRegister;
    private TextView tvLogIn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Initialize views
        etUserID = findViewById(R.id.etUserID);
        etFullName = findViewById(R.id.etFullName);
        etEmail = findViewById(R.id.etEmail);
        etPhoneNumber = findViewById(R.id.etPhoneNumber);
        etPassword = findViewById(R.id.etPassword);
        cbAgreeTerms = findViewById(R.id.cbAgreeTerms);
        btnRegister = findViewById(R.id.btnRegister);
        tvLogIn = findViewById(R.id.tvLogIn);

        // Set click listener for the register button
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userID = etUserID.getText().toString().trim();
                String fullName = etFullName.getText().toString().trim();
                String email = etEmail.getText().toString().trim();
                String phone = etPhoneNumber.getText().toString().trim();
                String password = etPassword.getText().toString().trim();

                // Validate inputs
                if (userID.isEmpty() || fullName.isEmpty() || email.isEmpty() || phone.isEmpty() || password.isEmpty() || !cbAgreeTerms.isChecked()) {
                    Toast.makeText(RegisterActivity.this, "Please fill all fields and agree to terms", Toast.LENGTH_SHORT).show();
                } else {
                    registerUser(userID, fullName, email, phone, password);
                }
            }
        });

        // Set click listener for the login text
        tvLogIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to login screen
                Intent intent = new Intent(RegisterActivity.this, SignInActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void registerUser(String userID, String fullName, String email, String phone, String password) {
        String url = "http://10.131.76.203/register.php"; // Replace with your backend API URL

        JSONObject userData = new JSONObject();
        try {
            userData.put("userID", userID);
            userData.put("fullName", fullName);
            userData.put("email", email);
            userData.put("phoneNumber", phone);
            userData.put("password", password);
            userData.put("roleID", 103);  // RoleID 103 for Student
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.POST,
                url,
                userData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            if (response.getBoolean("success")) {
                                Toast.makeText(RegisterActivity.this, "Registration Successful!", Toast.LENGTH_SHORT).show();
                                // Navigate to login page after successful registration
                                Intent intent = new Intent(RegisterActivity.this, SignInActivity.class);
                                startActivity(intent);
                                finish();
                            } else {
                                Toast.makeText(RegisterActivity.this, response.getString("message"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(RegisterActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
        );

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonObjectRequest);
    }
}
