package com.example.bustrackerapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Delay for 5 seconds and then navigate to SignInActivity
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Start the SignInActivity
                Intent intent = new Intent(MainActivity.this, SignInActivity.class);
                startActivity(intent);

                // Finish MainActivity so it's removed from the back stack
                finish();
            }
        }, 5000); // 5000 milliseconds = 5 seconds
    }
}
