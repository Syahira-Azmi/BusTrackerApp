package com.example.bustrackerapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AdminMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_menu);  // Use your XML file's name here

        // Initialize views
        LinearLayout busDetailsButton = findViewById(R.id.busDetails);
        LinearLayout tripHistoryButton = findViewById(R.id.tripHistory);
        LinearLayout routeInfoNav = findViewById(R.id.routeInfoNav);
        LinearLayout manageUserNav = findViewById(R.id.manageUserNav);
        LinearLayout profileNav = findViewById(R.id.profileNav);

        // Set click listener for Bus Details
        busDetailsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle Bus Details click
                Toast.makeText(AdminMenu.this, "Bus Details clicked", Toast.LENGTH_SHORT).show();
                // Start Bus Details Activity (create the activity first)
                Intent intent = new Intent(AdminMenu.this, BusDetails.class);
                startActivity(intent);
            }
        });

        // Set click listener for Trip History
        tripHistoryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle Trip History click
                Toast.makeText(AdminMenu.this, "Trip History clicked", Toast.LENGTH_SHORT).show();
                // Start Trip History Activity (create the activity first)
                Intent intent = new Intent(AdminMenu.this, TripHistory.class);
                startActivity(intent);
            }
        });

        // Set click listener for Route Info
        routeInfoNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle Route Info navigation click
                Toast.makeText(AdminMenu.this, "Route Info clicked", Toast.LENGTH_SHORT).show();
                startActivity(new Intent (AdminMenu.this,RouteInfo.class));
            }
        });

        // Set click listener for Manage User
        manageUserNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle Manage User navigation click
                Toast.makeText(AdminMenu.this, "Manage User clicked", Toast.LENGTH_SHORT).show();
                startActivity(new Intent (AdminMenu.this,ManageUser.class));
            }
        });

        // Set click listener for Profile
        profileNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle Profile navigation click
                Toast.makeText(AdminMenu.this, "Profile clicked", Toast.LENGTH_SHORT).show();
                startActivity(new Intent (AdminMenu.this,AdminProfile.class));
            }
        });
    }
}
