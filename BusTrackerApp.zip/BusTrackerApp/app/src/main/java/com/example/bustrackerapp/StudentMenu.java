package com.example.bustrackerapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.HashMap;
import java.util.Map;

public class StudentMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_menu);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        // Map to associate menu item IDs with activities
        Map<Integer, Class<?>> navigationMap = new HashMap<>();
        navigationMap.put(R.id.nav_schedule, BusSchedule.class);
        navigationMap.put(R.id.nav_alert, BusAlert.class);
        navigationMap.put(R.id.nav_profile, StudentProfile.class);

        // Set a listener to handle item selection
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            Class<?> targetClass = navigationMap.get(item.getItemId());
            if (targetClass != null) {
                startActivity(new Intent(StudentMenu.this, targetClass));
                return true;
            }
            return false;
        });

        // Do not set default selected item to avoid unintended navigation
    }
}
