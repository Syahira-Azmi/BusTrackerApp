package com.example.bustrackerapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class BusDT extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bus_dt);

        // Get references to navigation buttons
        LinearLayout BusStationIcon = findViewById(R.id.bus_station_icon);
        LinearLayout BusAvailableIcon = findViewById(R.id.bus_available_icon);

        // Set click listeners for each button
        BusStationIcon.setOnClickListener(v -> {
            // Show a toast message
            Toast.makeText(BusDT.this, "Bus Station Clicked", Toast.LENGTH_SHORT).show();

            // Navigate to the BusStation activity
            Intent intent = new Intent(BusDT.this, BusStation.class);
            startActivity(intent);
        });

        BusAvailableIcon.setOnClickListener(v -> {
            // Show a toast message
            Toast.makeText(BusDT.this, "Available Bus Clicked", Toast.LENGTH_SHORT).show();

            // Navigate to the AvailableBus activity
            Intent intent = new Intent(BusDT.this, AvailableBus.class);
            startActivity(intent);
        });

    }
}
