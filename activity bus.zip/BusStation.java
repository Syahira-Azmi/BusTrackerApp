package com.example.bustrackerapp;

import com.example.bustrackerapp.R;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;

import java.util.Objects;


public class BusStation extends AppCompatActivity {


    // Buttons for bus stations
    private Button btnStation1, btnStation2, btnStation3, btnStation4, btnStation5,
            btnStation6, btnStation7, btnStation8, btnStation9, btnStation10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bus_station); // Link to your XML file

        /* Initialize Back Button
        ivBack = findViewById(R.id.back_arrow);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Close activity
            }
        });
*/
        // Initialize Bottom Navigation Icons and Text
        // Declare UI elements
        // Get references to navigation buttons
        LinearLayout Homepage = findViewById(R.id.homepage);
        LinearLayout BusAvailableIcon = findViewById(R.id.bus_available_icon);
        LinearLayout ProfileIcon = findViewById(R.id.profile_icon);

        // Set click listeners for each button
        Homepage.setOnClickListener(v -> {
            // Show a toast message
            Toast.makeText(BusStation.this, "Homepage Clicked", Toast.LENGTH_SHORT).show();

            // Navigate to the BusStation activity
            Intent intent = new Intent(BusStation.this, Homepage.class);
            startActivity(intent);
        });

        //Bus Available
        BusAvailableIcon.setOnClickListener(v -> {
            // Show a toast message
            Toast.makeText(BusStation.this, "Available Bus Clicked", Toast.LENGTH_SHORT).show();

            // Navigate to the AvailableBus activity
            Intent intent = new Intent(BusStation.this, AvailableBus.class);
            startActivity(intent);
        });

        //Profile
        ProfileIcon.setOnClickListener(v -> {
            // Show a toast message
            Toast.makeText(BusStation.this, "Profile Clicked", Toast.LENGTH_SHORT).show();

            // Navigate to the AvailableBus activity
            Intent intent = new Intent(BusStation.this, StudentProfile.class);
            startActivity(intent);
        });


        // Initialize Buttons
        btnStation1 = findViewById(R.id.btnStation1);
        btnStation2 = findViewById(R.id.btnStation2);
        btnStation3 = findViewById(R.id.btnStation3);
        btnStation4 = findViewById(R.id.btnStation4);
        btnStation5 = findViewById(R.id.btnStation5);
        btnStation6 = findViewById(R.id.btnStation6);
        btnStation7 = findViewById(R.id.btnStation7);
        btnStation8 = findViewById(R.id.btnStation8);
        btnStation9 = findViewById(R.id.btnStation9);
        btnStation10 = findViewById(R.id.btnStation10);


        // Set onClick Listeners for Bus Station Buttons
        setButtonListeners();
    }

    // Click Listener for Bottom Navigation
    /*private final View.OnClickListener navClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            int id = v.getId();
            if (id == R.id.bus_station_icon || id == R.id.bus_station_text) {
                Toast.makeText(BusStation.this, "Bus Station selected", Toast.LENGTH_SHORT).show();
            } else if (id == R.id.profile_icon || id == R.id.profile_text) {
                Toast.makeText(BusStation.this, "Profile selected", Toast.LENGTH_SHORT).show();
            }
        }
    };

     */


    // Set Listeners for Bus Station Buttons
    private void setButtonListeners() {
        btnStation1.setOnClickListener(createStationClickListener("Kolej Kediaman Satria"));
        btnStation1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Navigate to BusSatria
                Intent intent = new Intent(BusStation.this,BusSatria.class);
                startActivity(intent);
            }
        });

        btnStation2.setOnClickListener(createStationClickListener("Kolej Kediaman Al-Jazari (AJ)"));
        btnStation2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Navigate to BusAJ
                Intent intent = new Intent(BusStation.this,BusAJ.class);
                startActivity(intent);
            }
        });

        btnStation3.setOnClickListener(createStationClickListener("Kolej Kediaman Lestari"));
        btnStation3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Navigate to BusAJ
                Intent intent = new Intent(BusStation.this,BusLestari.class);
                startActivity(intent);
            }
        });

        btnStation4.setOnClickListener(createStationClickListener("Kampus Induk (KI)"));
        btnStation4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Navigate to BusAJ
                Intent intent = new Intent(BusStation.this,BusKampusInduk.class);
                startActivity(intent);
            }
        });

        btnStation5.setOnClickListener(createStationClickListener("Kompleks Dewan Kuliah (KDK)"));
        btnStation5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Navigate to BusAJ
                Intent intent = new Intent(BusStation.this,BusKDK.class);
                startActivity(intent);
            }
        });

        btnStation6.setOnClickListener(createStationClickListener("Kampus Teknologi (KT)"));
        btnStation6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Navigate to BusAJ
                Intent intent = new Intent(BusStation.this,BusKT.class);
                startActivity(intent);
            }
        });

        btnStation7.setOnClickListener(createStationClickListener("Laluan Durian Tunggal (DT)"));
        btnStation7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Navigate to BusAJ
                Intent intent = new Intent(BusStation.this,BusDT.class);
                startActivity(intent);
            }
        });

        btnStation8.setOnClickListener(createStationClickListener("Kompleks Sukan UTeM (KSU)"));
        btnStation8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Navigate to BusAJ
                Intent intent = new Intent(BusStation.this,BusKSU.class);
                startActivity(intent);
            }
        });

        btnStation9.setOnClickListener(createStationClickListener("Pangsapuri Sri Utama (SU)"));
        btnStation9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Navigate to BusAJ
                Intent intent = new Intent(BusStation.this,BusSU.class);
                startActivity(intent);
            }
        });

        btnStation10.setOnClickListener(createStationClickListener("Emerald Park"));
        btnStation10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Navigate to BusAJ
                Intent intent = new Intent(BusStation.this,BusEmeraldPark.class);
                startActivity(intent);
            }
        });
    }

    // Helper Method to Create Click Listeners for Buttons
    private View.OnClickListener createStationClickListener(final String stationName) {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(BusStation.this, stationName + " clicked", Toast.LENGTH_SHORT).show();
            }
        };
    }

}
