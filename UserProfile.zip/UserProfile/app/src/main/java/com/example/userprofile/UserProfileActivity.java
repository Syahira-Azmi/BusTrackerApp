package com.example.userprofile;

import android.app.Activity;

public class UserProfileActivity extends Activity {
}
